package tn.techcare.PlateformeFormation.model;

import java.time.LocalTime;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "seance")
public class Seance {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_seance ;
	@JsonFormat(pattern="HH:mm")
	private LocalTime heuredeb ;
	@JsonFormat(pattern="HH:mm")
	private LocalTime heurefin ;
	 @JsonIgnore
	    @ManyToOne(cascade = CascadeType.ALL)
	    @JoinColumn(name = "id_formation")
	    private Formation formation ;
	
	public int getId_seance() {
		return id_seance;
	}
	public void setId_seance(int id_seance) {
		this.id_seance = id_seance;
	}

	
	public LocalTime getHeuredeb() {
		return heuredeb;
	}
	public void setHeuredeb(LocalTime heuredeb) {
		this.heuredeb = heuredeb;
	}
	public LocalTime getHeurefin() {
		return heurefin;
	}
	public void setHeurefin(LocalTime heurefin) {
		this.heurefin = heurefin;
	}
	public Formation getFormation() {
		return formation;
	}
	public void setFormation(Formation formation) {
		this.formation = formation;
	}

	
}
