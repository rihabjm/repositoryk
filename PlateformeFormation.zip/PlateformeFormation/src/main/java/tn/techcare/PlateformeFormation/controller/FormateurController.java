package tn.techcare.PlateformeFormation.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tn.techcare.PlateformeFormation.model.Formateur;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.service.FormateurService;



 
@CrossOrigin("*")
@RestController
@RequestMapping("/formateur")
public class FormateurController {

	@Autowired
	private  FormateurService formateurService ;
	
	@PostMapping("/add")
	private MessageReponse AjoutFormateur (@RequestBody Formateur formateur) {
		return formateurService.AjoutFormateur(formateur);
	}
	
  @GetMapping("/get")
  private List<Formateur> getallFormateur()
  {
	  return formateurService.getAllFormateur();
  }
  

@PutMapping("/update")
private MessageReponse ModifierFormateur (@RequestBody Formateur formateur ) {
	return formateurService.ModifierFormateur(formateur) ;
	
}


@DeleteMapping("{id}")
private MessageReponse SupprimerFormateur (@PathVariable("id") int id) {
	return formateurService.SupprimerFormateur(id) ;
	
}
	
}
