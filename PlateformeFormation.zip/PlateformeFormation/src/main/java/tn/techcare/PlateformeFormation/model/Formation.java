package tn.techcare.PlateformeFormation.model;

import java.sql.Date;
import java.util.List;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;



@Entity
@Table(name = "formation")
public class Formation {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_formation;
	private String intitule_formation ;
	private String langue ;
	private int nombreheure ;
	private float prix ;
	private String etat ;
   private String categorie ;
   private String type ;
   private Date datedebut ;
   private Date datefin ;
   private String image ;

	
	

	public String getImage() {
	return image;
}

public void setImage(String image) {
	this.image = image;
}

	public int getId_formation() {
		return id_formation;
	}

	public void setId_formation(int id_formation) {
		this.id_formation = id_formation;
	}

	public String getIntitule_formation() {
		return intitule_formation;
	}

	public void setIntitule_formation(String intitule_formation) {
		this.intitule_formation = intitule_formation;
	}

	public String getLangue() {
		return langue;
	}

	public void setLangue(String langue) {
		this.langue = langue;
	}

	public int getNombreheure() {
		return nombreheure;
	}

	public void setNombreheure(int nombreheure) {
		this.nombreheure = nombreheure;
	}

	public float getPrix() {
		return prix;
	}

	public void setPrix(float prix) {
		this.prix = prix;
	}
	


	public String getEtat() {
		return etat;
	}

	public void setEtat(String etat) {
		this.etat = etat;
	}

	public String getCategorie() {
		return categorie;
	}

	public void setCategorie(String categorie) {
		this.categorie = categorie;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Date getDatedebut() {
		return datedebut;
	}

	public void setDatedebut(Date datedebut) {
		this.datedebut = datedebut;
	}

	public Date getDatefin() {
		return datefin;
	}

	public void setDatefin(Date datefin) {
		this.datefin = datefin;
	}
	
	 
}
