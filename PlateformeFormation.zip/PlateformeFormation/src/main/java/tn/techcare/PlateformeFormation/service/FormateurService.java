package tn.techcare.PlateformeFormation.service;

import java.util.List;

import tn.techcare.PlateformeFormation.model.Formateur;
import tn.techcare.PlateformeFormation.model.MessageReponse;

 

public interface FormateurService {
	  public MessageReponse AjoutFormateur (Formateur formateur) ;
	  public List<Formateur> getAllFormateur();
      public MessageReponse ModifierFormateur(Formateur formateur) ;
	  public MessageReponse SupprimerFormateur(int id);
}
