package tn.techcare.PlateformeFormation.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

 
@Entity
@Table(name = "formateur")
public class Formateur  extends Utilisateur {
 
	private String cv ;
	
	@JsonIgnore
	@OneToMany(mappedBy = "formateur", cascade = {CascadeType.ALL})
	private List<Certificats> certificat ;
 

	 

	public List<Certificats> getCertificat() {
		return certificat;
	}

	public void setCertificat(List<Certificats> certificat) {
		this.certificat = certificat;
	}


	public List<Certificats> getCertificats() {
		return certificat;
	}

	public void setCertificats(List<Certificats> certificats) {
		this.certificat = certificats;
	}

	public String getCv() {
		return cv;
	}

	public void setCv(String cv) {
		this.cv = cv;
	}

	@Override
	public String toString() {
		return "Formateur [cv=" + cv + ", certificat=" + certificat +"]";
	}
	
	
	
	
	
	
	
}
