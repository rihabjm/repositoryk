package tn.techcare.PlateformeFormation.model;


import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "formationMetiers")
public class FormationMetiers extends Formation {

	@JsonIgnore
	  @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(name = "Module_Metiers")
    private List<FormationModule> FormationModule ;

	public List<FormationModule> getFormationModule() {
		return FormationModule;
	}

	public void setFormationModule(List<FormationModule> formationModule) {
		FormationModule = formationModule;
	}




}
