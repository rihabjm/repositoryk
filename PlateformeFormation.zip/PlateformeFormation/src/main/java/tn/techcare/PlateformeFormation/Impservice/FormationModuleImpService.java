package tn.techcare.PlateformeFormation.Impservice;

import java.util.List;


import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tn.techcare.PlateformeFormation.model.FormationModule;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.repository.FormationModuleRepository;
import tn.techcare.PlateformeFormation.service.FormationModuleService;
@Service
@Transactional
public class FormationModuleImpService implements FormationModuleService  {
	@Autowired
	private FormationModuleRepository formationmoduleRepository ;
	
	
	@Override
	public MessageReponse ajoutFormationModule(FormationModule formation) {
		
		
		formationmoduleRepository.save(formation);
		return new MessageReponse(true, formation.getId_formation()+ "formation est ajouter ") ;
	}


	@Override
	public List<FormationModule> getAllFormation() {
		return formationmoduleRepository.findAll();
	}


	@Override
	public MessageReponse updateFormation(FormationModule formation) {
		FormationModule	 module = formationmoduleRepository.findById(formation.getId_formation()).orElse(null) ;
		if(module== null) {
		return new MessageReponse(false, "erreur , formation  introuvable");
		}
		formationmoduleRepository.save(formation);
		return new MessageReponse(true, "operation modifier effectue avec succes");
	}


	@Override
	public MessageReponse supprimerFormation(int id) {
		FormationModule module = formationmoduleRepository.findById(id).orElse(null) ;
		if(module== null) {
		return new MessageReponse(false, "erreur , formation  introuvable");
		}
		formationmoduleRepository.delete(module);
		return new MessageReponse(true, "operation delet effectue avec succes");
	}

}
