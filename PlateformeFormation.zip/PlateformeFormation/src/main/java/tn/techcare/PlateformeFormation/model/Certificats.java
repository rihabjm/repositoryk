package tn.techcare.PlateformeFormation.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
 
@Entity
@Table(name = "certificat")
public class Certificats {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_C ;
	private String intitulé ;
	
	 @JsonIgnore
	    @ManyToOne(cascade = CascadeType.ALL)
	    @JoinColumn(name = "idFormateur")
	    private Formateur formateur ;

	public String getIntitulé() {
		return intitulé;
	}

	public void setIntitulé(String intitulé) {
		this.intitulé = intitulé;
	}

	public int getId_C() {
		return id_C;
	}

	public void setId_C(int id_C) {
		this.id_C = id_C;
	}

	public Formateur getFormateur() {
		return formateur;
	}

	public void setFormateur(Formateur formateur) {
		this.formateur = formateur;
	}

	@Override
	public String toString() {
		return "Certificats [id_C=" + id_C + ", intitulé=" + intitulé + ", formateur=" + formateur + "]";
	}
	
	
	
	
}
