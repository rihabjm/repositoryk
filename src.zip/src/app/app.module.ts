import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { HomeComponent } from './component/home/home.component';
import {FormationMEtierModule} from './component/formation-metier/formation-metier.module';
import {HTTP_INTERCEPTORS, HttpClientModule ,HttpParams ,HttpHeaders,HttpErrorResponse} from '@angular/common/http';
import { FormsModule, ReactiveFormsModule}  from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import {FormationmoduleModule} from './component/formationmodule/formationmodule.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {FormateurModule} from './component/formateur/formateur.module';
import {ProgkhdemniModule} from './component/progkhdemni/progkhdemni.module';
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormationMEtierModule ,FormateurModule,ProgkhdemniModule ,
FormsModule, ReactiveFormsModule,HttpClientModule  ,RouterModule ,FormationmoduleModule, BrowserAnimationsModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
