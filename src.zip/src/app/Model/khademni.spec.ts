import { Khademni } from './khademni';

describe('Khademni', () => {
  it('should create an instance', () => {
    expect(new Khademni()).toBeTruthy();
  });
});
