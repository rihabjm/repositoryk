import { EtatFormation } from './etat-formation';

describe('EtatFormation', () => {
  it('should create an instance', () => {
    expect(new EtatFormation()).toBeTruthy();
  });
});
