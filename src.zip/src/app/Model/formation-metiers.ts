import {EtatFormation} from './etat-formation';
export class FormationMetiers {
  id_formation:number ;
intitule_formation : String ;
langue :String ;
nombreheure :  number;
prix :number ;
categorie :String;
datedebut : Date;
datefin : Date ;
etat : String;
Promotion :String ;
type: String ;
image : String
}
