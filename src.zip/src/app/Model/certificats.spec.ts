import { Certificats } from './certificats';

describe('Certificats', () => {
  it('should create an instance', () => {
    expect(new Certificats()).toBeTruthy();
  });
});
