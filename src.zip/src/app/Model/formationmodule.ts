export class Formationmodule {
id_formation:number ;
intitule_formation : String ;
langue :String ;
nombreheure :  number;
prix :number ;
datedebut : String;
datefin:String ;
etat : String;
image :String ;
type: String ;
session: String ;


}
