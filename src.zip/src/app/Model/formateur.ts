
import{Certificats } from './certificats' ;
export class Formateur {
       id : number;
       nom : String;
	     prenom : String ;
	     adresse : String ;
	     mail : String ;
	     telephone: number ;
	     login : String;
	     mdp : String;
	     dateNAisse :Date;
	     niveauEtude : String;
	      cv : String;

       certificats  :Certificats ;


}
