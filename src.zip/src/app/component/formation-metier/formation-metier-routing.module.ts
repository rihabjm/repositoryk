import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FormationMetierComponent } from './formation-metier/formation-metier.component';
import { AddFormationComponent } from './add-formation/add-formation.component';
import { FormationMetierUpdateComponent } from './formation-metier-update/formation-metier-update.component';
import { FormationMetierListComponent } from './formation-metier-list/formation-metier-list.component';
const routes: Routes = [

{
        path: 'formationMetiers',
        component: FormationMetierComponent,
        children: [
            {
                path: 'add',
                component: AddFormationComponent
            } ,

        {
                path: 'update',
                component: FormationMetierUpdateComponent
            } ,
     {
                path: 'list',
                component: FormationMetierListComponent
            } ,


        ]
    }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FormationMEtierRoutingModule { }
