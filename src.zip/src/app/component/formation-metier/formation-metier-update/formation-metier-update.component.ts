import { Component, OnInit } from '@angular/core';
import {FormationMetiers} from '../../../Model/formation-metiers';
import {FormationMetiersService} from '../../../Service/formation-metiers.service';
@Component({
  selector: 'app-formation-metier-update',
  templateUrl: './formation-metier-update.component.html',
  styleUrls: ['./formation-metier-update.component.css']
})
export class FormationMetierUpdateComponent implements OnInit {

  constructor(private formationsmetiersservice :FormationMetiersService) { }

  ngOnInit() {
this.getAll() ;
  }

formationsmetiers: FormationMetiers[] = new Array();
private getAll() {
 this.formationsmetiersservice.getAll().subscribe(data => {
 this.formationsmetiers=data ;
      console.log(this.formationsmetiers);
    }, ex => {
      console.log(ex);
    });}



delete(id: number) {

    this.formationsmetiersservice.delete(id).subscribe(data => {
      if (data.success) {this.getAll();


} else {
  }

    }, ex => {

     console.log(ex);
    });
  }


 private update(formationsmetiers:FormationMetiers) {
    this.formationsmetiersservice.update(formationsmetiers).subscribe(
data => {

     if (data.success) { this.getAll();} else {}
    }, ex => {console.log(ex);
    });




  }




}









