import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormationMetierUpdateComponent } from './formation-metier-update.component';

describe('FormationMetierUpdateComponent', () => {
  let component: FormationMetierUpdateComponent;
  let fixture: ComponentFixture<FormationMetierUpdateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormationMetierUpdateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormationMetierUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
