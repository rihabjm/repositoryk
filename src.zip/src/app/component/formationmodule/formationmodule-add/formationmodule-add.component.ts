import { Component, OnInit } from '@angular/core';
import {Formationmodule} from '../../../Model/formationmodule';
import {FormationmoduleService} from '../../../Service/formationmodule.service';
import{EtatFormation} from'../../../Model/etat-formation';
import{EtatFormaionService} from'../../../Service/etat-formaion.service';
import{Categorie} from'../../../Model/categorie';
import {CategorieService} from'../../../Service/categorie.service';
import{Type} from '../../../Model/type';
import {TypeService} from'../../../Service/type.service';
import{Promotion} from '../../../Model/promotion';
import {PromotionService} from'../../../Service/promotion.service';
import {FormControl,FormGroup,Validators} from '@angular/forms';
@Component({
  selector: 'app-formationmodule-add',
  templateUrl: './formationmodule-add.component.html',
  styleUrls: ['./formationmodule-add.component.css']
})
export class FormationmoduleAddComponent implements OnInit {
fmetiers:Formationmodule=new Formationmodule ;
 etat :EtatFormation=new EtatFormation();
  constructor(private formationmetiersService:FormationmoduleService , private etatFormationservice :EtatFormaionService , private  categorieService:CategorieService , private typeservice:TypeService ,private promotionservice :PromotionService  ) { }
etatformations: EtatFormation[] = new Array();
categorieformations: Categorie[] = new Array();
typeformations:Type[]=new Array();
promotionformations:Promotion[]=new Array();
etatf :String ="" ;

  submitted = false;
  ngOnInit() {
this.submitted=false;

  }

ajouter()
{
this.formationmetiersService.save(this.fmetiers).subscribe( data => {

     if (data.success) {} else {}

}, ex => {console.log(ex);
    });
  }




FormationsaveForm =new FormGroup({
intitule_formation:new FormControl() ,
langue : new FormControl(),
nombreheure: new FormControl(),
prix:new FormControl(),
categorie:new FormControl(),
etat : new FormControl() ,
type : new FormControl() ,
datedebut:new FormControl(),
datefin:new FormControl(),
session:new FormControl()
})

saveFormation(saveFormation)
{
this.fmetiers=new Formationmodule();
this.fmetiers.intitule_formation =this.IntituleF.value ;
this.fmetiers.etat=this.EtatF.value ;
this.fmetiers.session=this.SessionF.value ;
this.fmetiers.prix=this.PrixF.value ;
this.fmetiers.nombreheure=this.NombreHeureF.value ;
this.fmetiers.type=this.TypeF.value ;
this.fmetiers.langue=this.LangueF.value ;
this.fmetiers.datedebut=this.Datedebut.value ;
this.fmetiers.datefin=this.Datefin.value ;
    this.submitted = true;

this.ajouter();
}

  get IntituleF (){
    return this.FormationsaveForm.get('intitule_formation');
  }
 get SessionF (){
    return this.FormationsaveForm.get('session');
  }

  get EtatF (){
    return this.FormationsaveForm.get('etat');
  }

  get CategorieF (){
    return this.FormationsaveForm.get('catgorie');
  }

  get TypeF (){
    return this.FormationsaveForm.get('type');
  }

 get LangueF (){
    return this.FormationsaveForm.get('langue');
  }

 get PrixF (){
    return this.FormationsaveForm.get('prix');
  }


 get NombreHeureF (){
    return this.FormationsaveForm.get('nombreheure');
  }



 get Datedebut (){
    return this.FormationsaveForm.get('datedebut');
  }



 get Datefin (){
    return this.FormationsaveForm.get('datefin');
  }



}
