import { Component, OnInit } from '@angular/core';
import {Formationmodule} from '../../../Model/formationmodule';
import {FormationmoduleService} from '../../../Service/formationmodule.service';
@Component({
  selector: 'app-formationmodule-update',
  templateUrl: './formationmodule-update.component.html',
  styleUrls: ['./formationmodule-update.component.css']
})
export class FormationmoduleUpdateComponent implements OnInit {
 constructor(private formationmoduleserice: FormationmoduleService) { }

  ngOnInit() {
this.getAll() ;
  }
formationsmodules: Formationmodule[] = new Array();
private getAll() {
 this.formationmoduleserice.getAll().subscribe(data => {
 this.formationsmodules=data ;
      console.log(this.formationsmodules);
    }, ex => {
      console.log(ex);
    });}

delete(id: number) {

    this.formationmoduleserice.delete(id).subscribe(data => {
      if (data.success) {this.getAll();


} else {
  }

    }, ex => {

     console.log(ex);
    });
  }


  private update(formationmodule:Formationmodule) {
    this.formationmoduleserice.update(formationmodule).subscribe(
data => {

     if (data.success) { this.getAll();} else {}
    }, ex => {console.log(ex);
    });
  }


}
