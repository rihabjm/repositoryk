import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FormationmoduleComponent } from './formationmodule/formationmodule.component';
import { FormationmoduleUpdateComponent } from './formationmodule-update/formationmodule-update.component';
import { FormationmoduleListComponent } from './formationmodule-list/formationmodule-list.component';
import { FormationmoduleAddComponent } from './formationmodule-add/formationmodule-add.component';

const routes: Routes = [
{
        path: 'Formationmodule',
        component: FormationmoduleComponent,
        children: [


        {
                path: 'update',
                component: FormationmoduleUpdateComponent
            } ,
     {
                path: 'list',
                component: FormationmoduleListComponent
            } ,
  {
                path: 'opop',
                component: FormationmoduleAddComponent
            } ,

        ]
    }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FormationmoduleRoutingModule { }
