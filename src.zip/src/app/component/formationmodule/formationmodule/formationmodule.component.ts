import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-formationmodule',
  templateUrl: './formationmodule.component.html',
  styleUrls: ['./formationmodule.component.css']
})
export class FormationmoduleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
