import { Component, OnInit } from '@angular/core';
import {Formationmodule} from '../../../Model/formationmodule';
import {FormationmoduleService} from '../../../Service/formationmodule.service';
@Component({
  selector: 'app-formationmodule-list',
  templateUrl: './formationmodule-list.component.html',
  styleUrls: ['./formationmodule-list.component.css']
})
export class FormationmoduleListComponent implements OnInit {

  constructor(private formationmoduleserice: FormationmoduleService) { }

  ngOnInit() {
this.getAll() ;
  }
formationsmodules: Formationmodule[] = new Array();
private getAll() {
 this.formationmoduleserice.getAll().subscribe(data => {
 this.formationsmodules=data ;
      console.log(this.formationsmodules);
    }, ex => {
      console.log(ex);
    });}
}
