import { Component, OnInit } from '@angular/core';
import {Formateur} from '../../../Model/formateur';
import {FormateurService} from '../../../Service/formateur.service';
@Component({
  selector: 'app-list-formateur',
  templateUrl: './list-formateur.component.html',
  styleUrls: ['./list-formateur.component.css']
})
export class ListFormateurComponent implements OnInit {

  constructor(private formateurservice :FormateurService) { }

  ngOnInit() {
this.getAll() ;
  }

formateur: Formateur[] = new Array();



private getAll() {
 this.formateurservice.getAll().subscribe(data => {
 this.formateur=data ;
      console.log(this.formateur);
    }, ex => {
      console.log(ex);
    });}

}
