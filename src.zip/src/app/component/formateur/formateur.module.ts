import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormateurRoutingModule } from './formateur-routing.module';
import { AddFormateurComponent } from './add-formateur/add-formateur.component';
import { UpdateFormateurComponent } from './update-formateur/update-formateur.component';
import { ListFormateurComponent } from './list-formateur/list-formateur.component';
import { FormateurComponent } from './formateur/formateur.component';
import { FormsModule, ReactiveFormsModule }  from '@angular/forms';

@NgModule({
  declarations: [AddFormateurComponent, UpdateFormateurComponent, ListFormateurComponent, FormateurComponent],
  imports: [
    CommonModule,
    FormateurRoutingModule ,FormsModule, ReactiveFormsModule
  ]
})
export class FormateurModule { }
