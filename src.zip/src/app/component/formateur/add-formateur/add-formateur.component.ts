import { Component, OnInit } from '@angular/core';
import { Formateur } from '../../../Model/formateur';

import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms' ;
import { FormateurService } from '../../../Service/formateur.service';
@Component({
  selector: 'app-add-formateur',
  templateUrl: './add-formateur.component.html',
  styleUrls: ['./add-formateur.component.css']
})
export class AddFormateurComponent implements OnInit {

  constructor(private formateurService: FormateurService ) { }
  formateur : Formateur =new Formateur() ;


  ngOnInit() {
  }


Ajouter() {

    this.formateurService.save(this.formateur).subscribe( data => {

     if (data.success) {
 } else {}

}, ex => {console.log(ex);
    });
  }

 nompattern = "[a-z A-Z]{1,20}$";
telPattern = "[0-9]{8}$" ;
FormateursaveForm =new FormGroup(
{
nom :new FormControl('' , [Validators.required , Validators.pattern(this.nompattern) ]) ,
prenom : new FormControl('' , [Validators.required , Validators.pattern(this.nompattern) ]),
adresse: new FormControl('' , [Validators.required , Validators.minLength(5) ]),
mail:new FormControl('',[Validators.required,Validators.email]),
telephone:new FormControl('' , [Validators.required , Validators.pattern(this.telPattern) ]),
dateNAisse :new FormControl() ,
niveauEtude : new FormControl(),
cv: new FormControl(),

})


saveFormateur(saveFormateur)
{
this.formateur=new Formateur();
this.formateur.nom =this.NomF.value ;
this.formateur.prenom=this.PrenomF.value ;
this.formateur.adresse =this.AdresseF.value ;
this.formateur.mail=this.MailF.value ;
this.formateur.telephone =this.TelephoneF.value ;
this.formateur.niveauEtude=this.NiveauEtudeF.value ;
this.formateur.dateNAisse =this.DateNAisseF.value ;
this.formateur.cv=this.CvF.value ;



this.Ajouter();
}

  get NomF (){
    return this.FormateursaveForm.get('nom');
  }

  get PrenomF (){
    return this.FormateursaveForm.get('prenom');
  }

  get AdresseF (){
    return this.FormateursaveForm.get('adresse');
  }

 get  MailF (){
    return this.FormateursaveForm.get('mail');
  }

 get TelephoneF (){
    return this.FormateursaveForm.get('telephone');
  }


 get NiveauEtudeF (){
    return this.FormateursaveForm.get('niveauEtude');
  }
  get   DateNAisseF (){
    return this.FormateursaveForm.get('dateNAisse');
  }


 get  CvF (){
    return this.FormateursaveForm.get('cv');
  }

}
