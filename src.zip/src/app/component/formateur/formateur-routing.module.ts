import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddFormateurComponent } from './add-formateur/add-formateur.component';
import { UpdateFormateurComponent } from './update-formateur/update-formateur.component';
import { ListFormateurComponent } from './list-formateur/list-formateur.component';
import { FormateurComponent } from './formateur/formateur.component';

const routes: Routes = [

{
        path: 'formateur',
        component: FormateurComponent,
        children: [
            {
                path: 'add',
                component: AddFormateurComponent
            } ,

        {
                path: 'update',
                component: UpdateFormateurComponent
            } ,
     {
                path: 'list',
                component: ListFormateurComponent
            } ,


        ]
    }





];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FormateurRoutingModule { }
