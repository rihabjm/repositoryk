import { Component, OnInit } from '@angular/core';
import {Formateur} from '../../../Model/formateur';
import {FormateurService} from '../../../Service/formateur.service';
@Component({
  selector: 'app-update-formateur',
  templateUrl: './update-formateur.component.html',
  styleUrls: ['./update-formateur.component.css']
})
export class UpdateFormateurComponent implements OnInit {

  constructor(private formateurservice :FormateurService) { }

  ngOnInit() {this.getAll() ;}

formateur: Formateur[] = new Array();



private getAll() {
 this.formateurservice.getAll().subscribe(data => {
 this.formateur=data ;
      console.log(this.formateur);
    }, ex => {
      console.log(ex);
    });}



private  delete(id: number) {

    this.formateurservice.delete(id).subscribe(data => {
      if (data.success) {this.getAll();


} else {
  }

    }, ex => {

     console.log(ex);
    });
  }



  private update(formateur:Formateur) {
    this.formateurservice.update(formateur).subscribe(
data => {

     if (data.success) { this.getAll();} else {}
    }, ex => {console.log(ex);
    });
  }

}
