import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UpdateComponent } from './update/update.component';

import { AddComponent } from './add/add.component';
import { ListComponent } from './list/list.component';
import { ProgkhdemniComponent } from './progkhdemni/progkhdemni.component';


const routes: Routes = [
{
        path: 'khdemni',
        component: ProgkhdemniComponent,
        children: [
            {
                path: 'ajouter',
                component: AddComponent
            } ,

        {
                path: 'update',
                component: UpdateComponent
            } ,
     {
                path: 'list',
                component:ListComponent
            } ,


        ]
    }








];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProgkhdemniRoutingModule { }
