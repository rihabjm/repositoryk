import { Component, OnInit } from '@angular/core';
import { Khademni } from '../../../Model/khademni';
import { KhademniServiceService } from '../../../Service/Khademni-service.service';
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  constructor(private  khdmnisrvice :KhademniServiceService) { }

  ngOnInit() { this.getAll() ;
  }
f : Khademni=new Khademni();
formations:Khademni [] = new Array();
private getAll() {
 this.khdmnisrvice.getAll().subscribe(data => {
 this.formations=data ;
      console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}

delete(id: number) {

    this.khdmnisrvice.delete(id).subscribe(data => {
      if (data.success) {this.getAll();


} else {
  }

    }, ex => {

     console.log(ex);
    });
  }


 private update(f:Khademni) {
    this.khdmnisrvice.update(f).subscribe(
data => {

     if (data.success) { this.getAll();} else {}
    }, ex => {console.log(ex);
    });




  }


}
