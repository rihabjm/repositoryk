import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { ProgkhdemniRoutingModule } from './progkhdemni-routing.module';
import { UpdateComponent } from './update/update.component';

import { AddComponent } from './add/add.component';
import { ListComponent } from './list/list.component';
import { ProgkhdemniComponent } from './progkhdemni/progkhdemni.component';
import {FormControl,FormGroup,Validators} from '@angular/forms';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
@NgModule({
  declarations: [UpdateComponent, AddComponent, ListComponent, ProgkhdemniComponent],
  imports: [
    CommonModule,
    ProgkhdemniRoutingModule ,RouterModule ,FormsModule, ReactiveFormsModule
  ]
})
export class ProgkhdemniModule { }
