import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-progkhdemni',
  templateUrl: './progkhdemni.component.html',
  styleUrls: ['./progkhdemni.component.css']
})
export class ProgkhdemniComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
