import { Component, OnInit } from '@angular/core';
import {FormControl,FormGroup,Validators } from '@angular/forms';
import { Khademni } from '../../../Model/khademni';
import { KhademniServiceService } from '../../../Service/Khademni-service.service';
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
   constructor(private khademniService: KhademniServiceService ) { }
  khademni : Khademni =new Khademni() ;


  ngOnInit() {}


Ajouter() {

    this.khademniService.save(this.khademni).subscribe( data => {

     if (data.success) {
 } else {}

}, ex => {console.log(ex);
    });
  }

khademnisaveForm =new FormGroup(
{
intitule :new FormControl('') ,
societe_daccuiel : new FormControl(''),
periode:new FormControl('')

})


SaveKhademni(saveKhademni)
{
this.khademni=new Khademni();
this.khademni.intitule =this.IntituleF.value ;
this.khademni.societe_daccuiel=this.societe_daccuielF.value ;
this.khademni.periode =this.Periode.value ;


this.Ajouter();
}

  get IntituleF (){
    return this.khademnisaveForm.get('intitule');
  }

  get societe_daccuielF (){
    return this.khademnisaveForm.get('societe_daccuiel');
  }

  get Periode (){
    return this.khademnisaveForm.get('periode');
  }



}
