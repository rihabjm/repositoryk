import { TestBed } from '@angular/core/testing';

import { FormationMetiersService } from './formation-metiers.service';

describe('FormationMetiersService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FormationMetiersService = TestBed.get(FormationMetiersService);
    expect(service).toBeTruthy();
  });
});
