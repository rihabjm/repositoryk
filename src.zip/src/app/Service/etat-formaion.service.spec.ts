import { TestBed } from '@angular/core/testing';

import { EtatFormaionService } from './etat-formaion.service';

describe('EtatFormaionService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: EtatFormaionService = TestBed.get(EtatFormaionService);
    expect(service).toBeTruthy();
  });
});
