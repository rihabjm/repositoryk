import { TestBed } from '@angular/core/testing';

import { KhademniServiceService } from './khademni-service.service';

describe('KhademniServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: KhademniServiceService = TestBed.get(KhademniServiceService);
    expect(service).toBeTruthy();
  });
});
