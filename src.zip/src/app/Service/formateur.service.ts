import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Config} from '../Utils/Config';
import {Observable} from 'rxjs';
import {Formateur} from '../Model/formateur';
@Injectable({
  providedIn: 'root'
})
export class FormateurService {
  constructor(private httpClient: HttpClient) { }

private url = Config.BASE_URL + '/formateur';
 public save(formateur:Formateur): Observable<any> {

  return this.httpClient.post(this.url+'/add',formateur );
  }

  public  getAll(): Observable<Formateur[]> {
    return this.httpClient.get<Formateur[]>(this.url+'/get');
  }
 public update(formateur:Formateur): Observable<any> {

  return this.httpClient.put(this.url+'/update' ,formateur);
  }


   public delete(id): Observable<any> {
    return this.httpClient.delete(this.url + '/' + id);
  }
}
