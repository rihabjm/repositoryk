import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Config} from '../Utils/Config';
import {Observable} from 'rxjs';
import {Promotion} from '../Model/promotion';
@Injectable({
  providedIn: 'root'
})
export class PromotionService {

  constructor(private httpClient: HttpClient) { }

private url = Config.BASE_URL + '/promotion';

  public  getAll(): Observable<Promotion[]> {
    return this.httpClient.get<Promotion[]>(this.url+'/get');
  }
}
