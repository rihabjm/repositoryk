import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Config} from '../Utils/Config';
import {Observable} from 'rxjs';
import {Type} from '../Model/type';
@Injectable({
  providedIn: 'root'
})
export class TypeService {

  constructor(private httpClient: HttpClient) { }
private url = Config.BASE_URL + '/typeFormation';

  public  getAll(): Observable<Type[]> {
    return this.httpClient.get<Type[]>(this.url+'/get');
  }


}
